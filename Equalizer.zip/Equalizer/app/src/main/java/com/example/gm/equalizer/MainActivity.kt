package com.example.gm.equalizer

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var count=0
    lateinit var lines: ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var layout=findViewById<ConstraintLayout>(R.id.constraint)
        layout.setOnClickListener {
           // for (item in 1..12) {
                if (count < 12) {
                    lines = ImageView(applicationContext)
                    lines.setImageDrawable(ContextCompat.getDrawable(applicationContext!!, R.drawable.line))
                    if (count <= 12) {

                        if (count >= 3 && count <= 5) {
                            // lines.setBackgroundColor(Color.GREEN)
                            lines.setImageDrawable(ContextCompat.getDrawable(applicationContext!!, R.drawable.line_red))
                            linearLayout.addView(lines)
                            count++
                        } else if (count > 5 && count <= 8) {
                            lines.setImageDrawable(
                                ContextCompat.getDrawable(
                                    applicationContext!!,
                                    R.drawable.line_blue
                                )
                            )
                            linearLayout.addView(lines)
                            count++
                        } else {
                            lines.setImageDrawable(
                                ContextCompat.getDrawable(
                                    applicationContext!!,
                                    R.drawable.line_pink
                                )
                            )
                            linearLayout.addView(lines)
                            count++
                        }
                    }


                }

        }
    }
}
